
INCLUDES=[u'X:\\Java18/include', u'X:\\Java18/include/win32']
CFLAGS=['/EHsc', '/D_CRT_SECURE_NO_WARNINGS']
DEBUG_CFLAGS=['/Od', '/DDEBUG']
LFLAGS=['/DLL', u'/LIBPATH:X:\\Java18/lib', 'Ws2_32.lib', 'jvm.lib']
IMPLIB_LFLAGS=['/IMPLIB:%s']
SHARED=True
VERSION="3.0"
