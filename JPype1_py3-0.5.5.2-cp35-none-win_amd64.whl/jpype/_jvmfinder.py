# *****************************************************************************
# Copyright 2013 Thomas Calmant
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
#
# *****************************************************************************

import os


class JVMFinder(object):
    """
    JVM library finder base class
    """
    def __init__(self):
        """
        Sets up members
        """
        # Library file name
        self._libfile = "libjvm.so"

        # Predefined locations
        self._locations = ("/usr/lib/jvm", "/usr/java")

        # Search methods
        self._methods = (self._get_from_java_home,
                         self._get_from_known_locations)

    def find_libjvm(self, java_home):
        """
        Recursively looks for the given file

        :param java_home: A Java home folder
        :param filename: Name of the file to find
        :return: The first found file path, or None
        """
        # Possible parents (in preference order)
        possible_parents = ('server', 'client', 'cacao', 'jamvm')

        # Look for the file
        for root, _, _ in os.walk(java_home):
            for parent in possible_parents:
                filename = os.path.join(root, parent, self._libfile)
                if os.path.exists(filename):
                    return filename
        else:
            # File not found
            return None

    def find_possible_homes(self, parents):
        """
        Generator that looks for the first-level children folders that could be
        Java installations, according to their name

        :param parents: A list of parent directories
        :return: The possible JVM installation folders
        """
        homes = []
        java_names = ('jre', 'jdk', 'java')
        for parent in parents:
            try:
                children = sorted(os.listdir(parent))
            except OSError:
                # Folder doesn't exist
                pass
            else:
                for childname in children:
                    # Compute the real path
                    path = os.path.realpath(os.path.join(parent, childname))
                    if path in homes or not os.path.isdir(path):
                        # Already known path, or not a directory -> ignore
                        continue

                    # Check if the path seems OK
                    real_name = os.path.basename(path).lower()
                    for java_name in java_names:
                        if java_name in real_name:
                            # Correct JVM folder name
                            homes.append(path)
                            yield path
                            break

    def get_jvm_path(self):
        """
        Retrieves the path to the default or first found JVM library

        :return: The path to the JVM shared library file
        :raise ValueError: No JVM library found
        """
        for method in self._methods:
            try:
                jvm = method()
            except NotImplementedError:
                # Ignore missing implementations
                pass
            else:
                if jvm is not None:
                    return jvm
        else:
            raise ValueError("No JVM shared library file ({0}) found. "
                             "Try setting up the JAVA_HOME environment "
                             "variable properly.".format(self._libfile))

    def _get_from_java_home(self):
        """
        Retrieves the Java library path according to the JAVA_HOME environment
        variable

        :return: The path to the JVM library, or None
        """
        # Get the environment variable
        java_home = os.getenv("JAVA_HOME")
        if java_home and os.path.exists(java_home):
            # Get the real installation path
            java_home = os.path.realpath(java_home)

            # Look for the library file
            return self.find_libjvm(java_home)

    def _get_from_known_locations(self):
        """
        Retrieves the first existing Java library path in the predefined known
        locations

        :return: The path to the JVM library, or None
        """
        for home in self.find_possible_homes(self._locations):
            jvm = self.find_libjvm(home)
            if jvm is not None:
                return jvm

    def normalize_arguments(self, jvm_lib_path, args):
        """
        Prepares the OS specific arguments required to start the JVM.

        :param jvm_lib_path: Path to the JVM library
        :param args: The list of arguments given to the JVM
        :return: The list of arguments to add for the JVM to start
        :raise OSError: Can't find required files
        """
        return args
