package jpype.array;

public class Test2 {
  public Object[] getValue() 
  {
    return new Object[0];
  }

  public Object test(Object o) 
  {
    return null;
  }
}